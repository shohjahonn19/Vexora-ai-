package com.vexora.ai

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.effect.Brightness
import androidx.media3.effect.Contrast
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.Presentation
import androidx.media3.effect.RgbAdjustment
import androidx.media3.effect.ScaleAndRotateTransformation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import java.io.File

/** Renders the plan on-device with Media3 Transformer (hardware encoder, no server). Call from the main thread. */
class Renderer(private val ctx: Context) {
    private var transformer: Transformer? = null
    private val handler = Handler(Looper.getMainLooper())

    fun render(
        video: Uri, music: File?, cuts: List<Cut>, look: Look, w: Int, h: Int, out: File,
        onProgress: (Float) -> Unit, onDone: (Result<Unit>) -> Unit
    ) {
        val clips = cuts.map { c ->
            val mi = MediaItem.Builder().setUri(video).setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(c.srcStartMs).setEndPositionMs(c.srcStartMs + c.lenMs).build()
            ).build()
            val fx = mutableListOf<Effect>()
            if (c.zoom) fx += ScaleAndRotateTransformation.Builder().setScale(look.zoom, look.zoom).build()
            if (look.contrast != 0f) fx += Contrast(look.contrast.coerceIn(-1f, 1f))
            if (look.brightness != 0f) fx += Brightness(look.brightness.coerceIn(-1f, 1f))
            if (look.red != 1f || look.blue != 1f)
                fx += RgbAdjustment.Builder().setRedScale(look.red).setBlueScale(look.blue).build()
            if (look.saturation != 0f)
                fx += HslAdjustment.Builder().adjustSaturation(look.saturation.coerceIn(-100f, 100f)).build()
            fx += Presentation.createForWidthAndHeight(w, h, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP)
            EditedMediaItem.Builder(mi).setRemoveAudio(music != null).setEffects(Effects(emptyList(), fx)).build()
        }
        val sequences = mutableListOf(EditedMediaItemSequence(clips))
        if (music != null) {
            val total = cuts.sumOf { it.lenMs }
            val mm = MediaItem.Builder().setUri(Uri.fromFile(music)).setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder().setEndPositionMs(total).build()
            ).build()
            sequences += EditedMediaItemSequence(listOf(EditedMediaItem.Builder(mm).setRemoveVideo(true).build()))
        }

        val t = Transformer.Builder(ctx)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    handler.removeCallbacksAndMessages(null); onDone(Result.success(Unit))
                }
                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                    handler.removeCallbacksAndMessages(null); onDone(Result.failure(exportException))
                }
            }).build()
        transformer = t
        out.parentFile?.mkdirs(); if (out.exists()) out.delete()
        t.start(Composition.Builder(sequences).build(), out.absolutePath)

        val holder = ProgressHolder()
        val poll = object : Runnable {
            override fun run() {
                if (t.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) onProgress(holder.progress / 100f)
                handler.postDelayed(this, 300)
            }
        }
        handler.post(poll)
    }

    fun cancel() { handler.removeCallbacksAndMessages(null); transformer?.cancel() }
}
