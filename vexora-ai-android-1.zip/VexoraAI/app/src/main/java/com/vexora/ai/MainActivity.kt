package com.vexora.ai

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val vm: AppViewModel = viewModel()
            val dark = when (vm.theme) { "dark" -> true; "light" -> false; else -> isSystemInDarkTheme() }
            MaterialTheme(
                colorScheme = if (dark) darkColorScheme(
                    primary = Color(0xFF8B5CF6), secondary = Color(0xFF22D3EE),
                    background = Color(0xFF0B0B12), surface = Color(0xFF14141F)
                ) else lightColorScheme(
                    primary = Color(0xFF6D3BE0), secondary = Color(0xFF0891B2),
                    background = Color(0xFFF7F7FB), surface = Color.White
                )
            ) { VexoraApp(vm) }
        }
    }
}
